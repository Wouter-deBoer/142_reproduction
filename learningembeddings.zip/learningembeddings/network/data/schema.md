## Database Schema
This document outlines the organization of the data stored as a `.json` file.
```
token{
    "token": "f8bac77d-2d46-4fe2-bcc1-2c781585ed49",
    "image_path": "2017_01_30R",
    "image_name": "ETHZ_ENT01_2017_01_30_000064.JPG",
    "family": "Hesperiidae",
    "subfamily": "Heteropterinae",
    "genus": "Carterocephalus",
    "specific_epithet": "palaemon",
    "subspecific_epithet": "",
    "infraspecific_epithet": "",
    "author": "(Pallas, 1771)",
    "country": "Switzerland",
    "primary_division": "Bern",
    "dec_lat": 46.9479774284,
    "dec_long": 7.447437875,
    "barcode": "ETHZ-ENT0003493"
}
```